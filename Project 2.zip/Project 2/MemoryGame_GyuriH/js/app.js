/*
 * Create a list that holds all of your cards
 */
const cards = document.querySelectorAll('.card');

let cardsArray = [...cards];
console.log(cardsArray);
const deck = document.querySelector('.deck');

//moves
let moves = 0;
let movesText = document.querySelector('.moves');


//count moves made
function addMove(){
  moves++;
  movesText.innerHTML = moves;
  if(moves == 1){
      second = 0;
      minute = 0;
      hour = 0;
      startTimer();
  }
  // setting rates based on moves
  if (moves > 8 && moves < 12){
      for( i= 0; i < 3; i++){
          if(i > 1){
              stars[i].style.visibility = "collapse";
          }
      }
  }
  else if (moves > 13){
      for( i= 0; i < 3; i++){
          if(i > 0){
              stars[i].style.visibility = "collapse";
          }
      }
  }
}

//variables for star icons
const stars = document.querySelectorAll(".fa-star");

//List of stars
let starsList = document.querySelectorAll('.stars li');

let matchedCards = 0;




//Toggle Card
function toggleCard(clickTarget){
  clickTarget.classList.toggle('open');
  clickTarget.classList.toggle('show');
}

//click cards (toggle and check for match)
deck.addEventListener('click', event => {
  const clickTarget = event.target;
  if (clickTarget.classList.contains('card') && toggledCards.length < 2 && !clickTarget.classList.contains('match') && !toggledCards.includes(clickTarget)){
    toggleCard(clickTarget);
    addToggleCard(clickTarget);
    if (toggledCards.length === 2){
      addMove();
      checkForMatch(clickTarget);
    }
  }
});

//Array that stores toggled cards
let toggledCards = [];

//Add clicked cards to 'toggledCards' array
function addToggleCard(clickTarget){
  toggledCards.push(clickTarget);
}

//function to check for match
function checkForMatch(){
  if (toggledCards[0].firstElementChild.className === toggledCards[1].firstElementChild.className){
    toggledCards[0].classList.toggle('match');
    toggledCards[1].classList.toggle('match');
    toggledCards = [];
    matchedCards += 2;
    if (matchedCards == 16) {
      document.querySelectorAll('.modal_background')[0].classList.toggle('hide');
      stopTimer();
      getModalStats();
    }
  } else {
    setTimeout(function(){
      toggleCard(toggledCards[0]);
      toggleCard(toggledCards[1]);
      toggledCards = [];
    }, 1000);
  }
}


/*
 * Display the cards on the page
 *   - shuffle the list of cards using the provided "shuffle" method below
 *   - loop through each card and create its HTML
 *   - add each card's HTML to the page
 */

// Shuffle function from http://stackoverflow.com/a/2450976
function shuffle(array) {
    var currentIndex = array.length, temporaryValue, randomIndex;

    while (currentIndex !== 0) {
        randomIndex = Math.floor(Math.random() * currentIndex);
        currentIndex -= 1;
        temporaryValue = array[currentIndex];
        array[currentIndex] = array[randomIndex];
        array[randomIndex] = temporaryValue;
    }

    return array;
}


// @description shuffles cards when page is refreshed / loads
document.body.onload = startGame();


// @description function to start a new play
function startGame(){
    // shuffle deck
    cardsArray = shuffle(cardsArray);
    // remove all exisiting classes from each card
    for (var i = 0; i < cardsArray.length; i++){
        deck.innerHTML = "";
        [].forEach.call(cardsArray, function(item) {
            deck.appendChild(item);
        });
        cardsArray[i].classList.remove("show", "open", "match");
    }
    // reset moves
    moves = 0;
    movesText.innerHTML = moves;
    // reset rating
    for (var i= 0; i < stars.length; i++){
        stars[i].style.color = "#FFD700";
        stars[i].style.visibility = "visible";
    }
    //reset timer
    second = 0;
    minute = 0;
    hour = 0;
    var timer = document.querySelector(".timer");
    timer.innerHTML = "0 mins 0 secs";
    clearInterval(interval);
}





// @description game timer
var second = 0, minute = 0; hour = 0;
var timer = document.querySelector(".timer");
var interval;
function startTimer(){
    interval = setInterval(function(){
        timer.innerHTML = minute+"mins "+second+"secs";
        second++;
        if(second == 60){
            minute++;
            second=0;
        }
        if(minute == 60){
            hour++;
            minute = 0;
        }
    },1000);
}

function displayTime(){
  timer.innerHTML = time;
}

let timerOff = true;
deck.addEventListener('click', event => {
  const clickTarget = event.target;
  if(isClickValid(clickTarget)){
    if(timerOff){
      startTimer();
      timerOff = false;
    }
  }
});

let time = 0;

function stopTimer(){
  clearInterval(interval);
}


//For Stat Modal

function toggleModal(){
  const modal = document.querySelector('.modal_background');
  modal.classList.toggle('hide');
}

function getModalStats(){
  let timeStat = document.querySelector('.modal_time');
  let movesStat = document.querySelector('.modal_moves');
  let starsStat = document.querySelector('.modal_stars');

  let stars = getStars();

  timeStat.innerHTML = 'Time = ' + timer.innerHTML;
  movesStat.innerHTML = 'Moves = ' + moves;
  starsStat.innerHTML = 'Stars = ' + stars;
}

function getStars(){
  let stars = document.querySelectorAll('.stars li');
  starCount = 0;
  for(star of stars){
    if(star.style.display !== 'none'){
      starCount++;
    }
  }
  console.log(starCount);
  return starCount;
}

//modal buttons
//Cancel button
document.querySelector('.modal_cancel').addEventListener('click', () => {
  toggleModal();
});
//Replay button
//document.querySelector('.modal_replay').addEventListener('click', resetGame);

document.querySelector('.modal_replay').addEventListener('click', () => {
  startGame();
  toggleModal();
});


document.querySelector('.restart').addEventListener('click',() => {
  startGame();
});

/*
 * set up the event listener for a card. If a card is clicked:
 *  - display the card's symbol (put this functionality in another function that you call from this one)
 *  - add the card to a *list* of "open" cards (put this functionality in another function that you call from this one)
 *  - if the list already has another card, check to see if the two cards match
 *    + if the cards do match, lock the cards in the open position (put this functionality in another function that you call from this one)
 *    + if the cards do not match, remove the cards from the list and hide the card's symbol (put this functionality in another function that you call from this one)
 *    + increment the move counter and display it on the page (put this functionality in another function that you call from this one)
 *    + if all cards have matched, display a message with the final score (put this functionality in another function that you call from this one)
 */
